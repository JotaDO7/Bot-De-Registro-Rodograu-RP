const fs = require('fs');
const path = require('path');

const dataPath = path.join(__dirname, 'registro.json');

function obterUltimoId() {
  if (!fs.existsSync(dataPath)) {
    fs.writeFileSync(dataPath, JSON.stringify({ ultimo_id: 0 }, null, 2));
    return 0;
  }

  const raw = fs.readFileSync(dataPath, 'utf-8');
  if (!raw.trim()) return 0;

  try {
    const data = JSON.parse(raw);
    return data.ultimo_id || 0;
  } catch (err) {
    console.error('❌ Erro ao ler registro.json:', err);
    return 0;
  }
}

function atualizarUltimoId(novoId) {
  fs.writeFileSync(dataPath, JSON.stringify({ ultimo_id: novoId }, null, 2));
}

module.exports = { obterUltimoId, atualizarUltimoId };
