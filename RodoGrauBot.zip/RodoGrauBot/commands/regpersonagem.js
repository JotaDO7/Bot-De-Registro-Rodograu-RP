const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const config = require('../config.json');
const { obterUltimoId, atualizarUltimoId } = require('../utils'); // funções de controle de ID

function gerarCPF() {
  const rand = () => Math.floor(Math.random() * 9);
  let cpf = Array.from({ length: 9 }, rand).join('');
  cpf += '00'; // final fake
  return cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('regpersonagem')
    .setDescription('Registrar um personagem de RP')
    .addStringOption(opt =>
      opt.setName('nome')
        .setDescription('Nome do personagem')
        .setRequired(true))
    .addIntegerOption(opt =>
      opt.setName('idade')
        .setDescription('Idade do personagem')
        .setRequired(true))
    .addStringOption(opt =>
      opt.setName('cnh')
        .setDescription('Tem CNH?')
        .addChoices(
          { name: 'Sim', value: 'Sim' },
          { name: 'Não', value: 'Não' }
        )
        .setRequired(true))
    .addStringOption(opt =>
      opt.setName('roblox')
        .setDescription('Seu nome de usuário do Roblox')
        .setRequired(true)
    ),

  async execute(interaction) {
    const nome = interaction.options.getString('nome');
    const idade = interaction.options.getInteger('idade');
    let cnh = interaction.options.getString('cnh');
    const roblox = interaction.options.getString('roblox');
    const autor = interaction.user; // quem executou o comando
    const cpf = gerarCPF();

    // Validação CNH
    if (idade < 18 && cnh === 'Sim') {
      cnh = 'Não (menor de idade)';
    }

    // ID automático
    const ultimoId = obterUltimoId();
    const novoId = ultimoId + 1;
    atualizarUltimoId(novoId);

    // Embed
    const embed = new EmbedBuilder()
      .setTitle('📄 Registro de Personagem')
      .setDescription(`👤 Registro feito por: <@${autor.id}>`)
      .addFields(
        { name: '🆔 ID do Registro', value: novoId.toString(), inline: true },
        { name: '👤 Nome do Personagem', value: nome, inline: true },
        { name: '🎂 Idade', value: idade.toString(), inline: true },
        { name: '🪪 CNH', value: cnh, inline: true },
        { name: '🧾 CPF', value: cpf, inline: true },
        { name: '🤖 Nick do Roblox', value: roblox, inline: true }
      )
      .setColor('Blue')
      .setTimestamp();

    // Resposta ao usuário
    await interaction.reply({
      content: `✅ Personagem registrado com sucesso! ID: ${novoId}`,
      flags: 1 << 6 // Resposta oculta (ephemeral de forma correta)
    });

    // Log no canal configurado
    const logChannel = interaction.client.channels.cache.get(config.log_personagem);
    if (logChannel) {
      logChannel.send({ embeds: [embed] });
    }
  }
};
