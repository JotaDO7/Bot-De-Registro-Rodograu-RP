const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const config = require('../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('regveiculo')
    .setDescription('Registrar um veículo no RP')
    .addStringOption(opt =>
      opt.setName('modelo').setDescription('Modelo da moto').setRequired(true))
    .addStringOption(opt =>
      opt.setName('placa').setDescription('Placa do veículo').setRequired(true))
    .addStringOption(opt =>
      opt.setName('dono').setDescription('Nome do dono').setRequired(true))
    .addStringOption(opt =>
      opt.setName('cor').setDescription('Cor do veículo').setRequired(false))
    .addStringOption(opt =>
      opt.setName('imagem').setDescription('URL da imagem do veículo').setRequired(false))
    .addStringOption(opt =>
      opt.setName('observacao').setDescription('Observações').setRequired(false)),

  async execute(interaction) {
    const modelo = interaction.options.getString('modelo');
    const placa = interaction.options.getString('placa');
    const dono = interaction.options.getString('dono');
    const cor = interaction.options.getString('cor') || 'Não informada';
    const imagem = interaction.options.getString('imagem');
    const observacao = interaction.options.getString('observacao') || 'Nenhuma';

    const embed = new EmbedBuilder()
      .setTitle('🛵 Registro de Veículo')
      .addFields(
        { name: '🚧 Modelo', value: modelo, inline: true },
        { name: '📋 Placa', value: placa, inline: true },
        { name: '👤 Dono', value: dono, inline: true },
        { name: '🎨 Cor', value: cor, inline: true },
        { name: '📝 Observações', value: observacao, inline: false }
      )
      .setColor('Green')
      .setTimestamp();

    if (imagem) {
      embed.setImage(imagem);
    }

    await interaction.reply({ content: '✅ Veículo registrado com sucesso!', ephemeral: true });

    const logChannel = interaction.client.channels.cache.get(config.log_veiculo);
    if (logChannel) {
      logChannel.send({ embeds: [embed] });
    }
  }
};
